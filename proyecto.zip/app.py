import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

url = 'data/datos_vias.csv'
df = pd.read_csv(url)

pg = st.navigation([
    st.Page("pages/inicio.py", title="Inicio", default=True),
    st.Page("pages/dispersion.py", title="Grafico de Dispersion"),
    st.Page("pages/categoria.py", title="Longitud por Categoria y Municipio"),
    st.Page("pages/estado.py", title="Comparación de Estado por Municipio"),
    st.Page("pages/correlacion.py", title="Mapa de Correlacion"),
])
pg.run()
